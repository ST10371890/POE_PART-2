﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace POE_PART1_CMCS
{

    public static class DatabaseHelper
    {
        private static string connectionString = "Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True";

        // Method to save a list of claims to the database
        public static bool SaveClaims(List<Claim> claimsList)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (Claim claim in claimsList)
                    {
                        // Insert query to save each claim to the Claims table
                        string query = "INSERT INTO Claims (LecturerId, Module, HoursWorked, HourlyRate, DocumentPath) " +
                                       "VALUES (@LecturerId, @Module, @HoursWorked, @HourlyRate, @DocumentPath)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Add parameters to prevent SQL injection
                            command.Parameters.AddWithValue("@LecturerId", claim.LecturerId);
                            command.Parameters.AddWithValue("@Module", claim.Module);
                            command.Parameters.AddWithValue("@HoursWorked", claim.HoursWorked);
                            command.Parameters.AddWithValue("@HourlyRate", claim.HourlyRate);
                            command.Parameters.AddWithValue("@DocumentPath", claim.DocumentPath ?? (object)DBNull.Value); // Set null if no document is uploaded

                            // Execute the insert command
                            command.ExecuteNonQuery();
                        }
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                // Log or display the error
                MessageBox.Show("An error occurred while saving claims: " + ex.Message);
                return false;
            }
        }

        // Method to save the document path to the database
        public static bool SaveDocumentPath(int claimId, string documentPath)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL query to update the document path for the given claim ID
                    string query = "UPDATE Claims SET DocumentPath = @DocumentPath WHERE Id = @ClaimId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@DocumentPath", documentPath);
                        command.Parameters.AddWithValue("@ClaimId", claimId);

                        // Execute the query to update the document path
                        int rowsAffected = command.ExecuteNonQuery();

                        // Return true if the update was successful
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Log or display the error
                MessageBox.Show("An error occurred while saving the document path: " + ex.Message);
                return false;
            }
        }
    }
}