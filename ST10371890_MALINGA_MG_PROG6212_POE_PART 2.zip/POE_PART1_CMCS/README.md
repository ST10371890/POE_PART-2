# POE_PART1_CMCS

Contract Monthly Claim System (CMCS) Prototype
Version: 1.0 (Non-functional Prototype)
Date: September 2024
Author: Mpho

Project Overview
The Contract Monthly Claim System (CMCS) is a Windows Presentation Framework (WPF)-based application designed to streamline the process of claim submissions, approvals, and status tracking within academic institutions. This prototype is part of the Portfolio of Evidence (PoE) for the PROG6212 module, focusing on the visual design and architecture without functional implementation.

Key Features
Lecturer Dashboard:

Submit monthly claims for work completed.
Upload supporting documents.
Coordinator Dashboard:

View pending claims.
Approve or reject claims.
Claim Status Tracker:

Track the status of submitted claims from submission to approval.
Structure of the Project
Frontend (WPF Prototype):
The prototype includes a user-friendly graphical interface where lecturers, program coordinators, and academic managers can interact with the system.
Non-functional Prototype:
This version is purely visual and does not handle backend data or business logic.
The interface includes navigational buttons and sample UI components based on project requirements.
UML Class Diagram
The project also includes a UML class diagram that outlines the structure and relationships between entities in the system. The diagram highlights key data attributes such as ClaimID, LecturerName, TotalHours, and ClaimStatus.

The UML diagram file is located in the /diagrams folder.

Project Plan
A comprehensive project plan with timelines and deliverables is provided. This outlines key tasks such as designing the UI, developing the UML diagram, and creating documentation.

The project plan file is located in the /docs folder.

Setup Instructions
To run this non-functional prototype on your machine, follow these steps:

Clone the Repository:

bash
Copy code
git clone https://github.com/ST10371890/CMCS_PART1_POE.git
cd CMCS-Prototype
Open in Visual Studio:

Open the CMCSPrototype.sln solution file in Visual Studio.
Install Dependencies:

Ensure you have .NET Core installed. Install any required NuGet packages by going to:
Tools → NuGet Package Manager → Manage NuGet Packages for Solution.
Run the Project:

Build the solution (Ctrl+Shift+B).
Run the prototype by pressing F5 or clicking Start.
Version Control
This project follows proper version control practices with frequent commits and clear, descriptive messages for each change. To contribute to this project:

Fork the repository.
Create a new branch for your feature:
bash
Copy code
git checkout -b feature/your-feature-name
Commit your changes:
bash
Copy code
git commit -m "Add description of the change"
Push to the branch:
bash
Copy code
git push origin feature/your-feature-name
Submit a pull request.
Future Work (Part 2)
In the next phase of the project, the prototype will be converted into a functional system. The core business logic, database integration, and claim submission functionality will be implemented. Lecturers will be able to submit claims, coordinators will approve them, and the system will track each claim’s status in real-time.

License
This project is licensed under the Apache-2.0 license. See the LICENSE file for more details.

