﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_PART1_CMCS
{
    /// <summary>
    /// Interaction logic for StatusWindow.xaml
    /// </summary>
    public partial class StatusWindow : Window
    {
        public List<Claim> Claims { get; set; } // List to hold claims

        public StatusWindow()
        {
            InitializeComponent();
            LoadClaims(); // Load claims into the DataGrid when the window is initialized
        }

        // Load claims from the database into the DataGrid
        private void LoadClaims()
        {
            Claims = new List<Claim>();
            string connectionString = "Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ClaimID, HoursWorked, Status FROM Claims WHERE Status = 'Pending'";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Claims.Add(new Claim
                        {
                            claimId = reader["ClaimID"].ToString(),
                            LecturerName = reader["LecturerName"].ToString(),
                            TotalHours = (int)reader["TotalHours"],
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }

            // Bind the list to the DataGrid
            ClaimedStatusDataGrid.ItemsSource = Claims;
        }

        // Handle DataGrid selection changed
        private void ClaimedStatusDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ClaimedStatusDataGrid.SelectedItem is Claim selectedClaim)
            {
                txtClaimID.Text = selectedClaim.claimId;
                txtStatus.Text = selectedClaim.Status;

                btnApproveClaim.IsEnabled = selectedClaim.Status == "Pending";
                btnRejectClaim.IsEnabled = selectedClaim.Status == "Pending";
            }
            else
            {
                txtClaimID.Text = string.Empty;
                txtStatus.Text = string.Empty;
                btnApproveClaim.IsEnabled = false;
                btnRejectClaim.IsEnabled = false;
            }
        }

        // Approve claim button click event
        private void btnApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimedStatusDataGrid.SelectedItem is Claim selectedClaim)
            {
                UpdateClaimStatusInDatabase(selectedClaim.claimId, "Approved");
                MessageBox.Show($"Claim {selectedClaim.ClaimID} approved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadClaims(); // Refresh the claims list
            }
        }

        // Reject claim button click event
        private void btnRejectClaim_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimedStatusDataGrid.SelectedItem is Claim selectedClaim)
            {
                UpdateClaimStatusInDatabase(selectedClaim.claimId, "Rejected");
                MessageBox.Show($"Claim {selectedClaim.ClaimID} rejected successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadClaims(); // Refresh the claims list
            }
        }

        // Method to update claim status in the database
        private void UpdateClaimStatusInDatabase(string claimID, string newStatus)
        {
            string connectionString = "Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Claims SET Status = @Status WHERE ClaimID = @ClaimID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Status", newStatus);
                    command.Parameters.AddWithValue("@ClaimID", claimID);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
 }
