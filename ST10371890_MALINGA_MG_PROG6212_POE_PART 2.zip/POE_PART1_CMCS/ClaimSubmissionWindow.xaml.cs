﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.Win32; // For OpenFileDialog
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.IO;
using Path = System.IO.Path;

namespace POE_PART1_CMCS
{
    /// <summary>
    /// Interaction logic for ClaimSubmissionWindow.xaml
    /// </summary>
    public partial class ClaimSubmissionWindow : Window
    {
        private string uploadedFilePath;
        private static string connectionString;

        public ClaimSubmissionWindow()
        {
            InitializeComponent();
        }

        // Browse file click event
        private void BrowseFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf|Word files (*.docx)|*.docx|Excel files (*.xlsx)|*.xlsx",
                Title = "Select Supporting Document",
                Multiselect = false
            };

            if (openFileDialog.ShowDialog() == true)
            {
                // Get the selected file path
                string selectedFile = openFileDialog.FileName;
                FileInfo fileInfo = new FileInfo(selectedFile);

                // Validate file size (e.g., limit to 10MB)
                if (fileInfo.Length > 10 * 1024 * 1024)
                {
                    MessageBox.Show("File size should not exceed 10MB.", "File Too Large", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Display the file name in the textbox
                txtFilePath.Text = fileInfo.Name;
                uploadedFilePath = selectedFile;
            }
        }

        // Submit claim button click event
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Ensure a file is selected
            if (string.IsNullOrEmpty(uploadedFilePath))
            {
                MessageBox.Show("Please upload a supporting document.", "Missing Document", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Save the file to a secure location
            string securePath = SaveFile(uploadedFilePath);

            // Save the claim to the database along with the file path
            SaveClaims(securePath);

            MessageBox.Show("Claim submitted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SaveClaims(string securePath)
        {
            throw new NotImplementedException();
        }

        // Method to save file to a secure directory
        private string SaveFile(string sourceFilePath)
        {
            string secureDirectory = @"C:\ClaimsDocuments"; // You can change this path to your secure location
            Directory.CreateDirectory(secureDirectory); // Ensure the directory exists

            string fileName = Path.GetFileName(sourceFilePath);
            string destinationFilePath = Path.Combine(secureDirectory, fileName);

            // Copy the file to the secure directory
            File.Copy(sourceFilePath, destinationFilePath, true);

            return destinationFilePath; // Return the full path of the saved file
        }

        public static bool SaveClaims(List<Claim> claimsList)
        {
            string connectionString = "Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (var claim in claimsList)
                    {
                        string query = "INSERT INTO Claims (LecturerID, LecturerName, LecturerSurname, EmployeeNumber, ContactNumber, ModuleName, HoursWorked, HourlyRate, Status) " +
                                       "VALUES (@LecturerID, @LecturerName, @LecturerSurname, @EmployeeNumber, @ContactNumber, @ModuleName, @HoursWorked, @HourlyRate, 'Pending')";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Set parameters and log them for debugging
                            command.Parameters.AddWithValue("@LecturerID", claim.LecturerID);
                            command.Parameters.AddWithValue("@LecturerName", claim.LecturerName);
                            command.Parameters.AddWithValue("@LecturerSurname", claim.LecturerSurname);
                            command.Parameters.AddWithValue("@EmployeeNumber", claim.EmployeeNumber);
                            command.Parameters.AddWithValue("@ContactNumber", claim.ContactNumber);
                            command.Parameters.AddWithValue("@ModuleName", claim.ModuleName);
                            command.Parameters.AddWithValue("@HoursWorked", claim.HoursWorked);
                            command.Parameters.AddWithValue("@HourlyRate", claim.HourlyRate);

                            // Log the query and parameters for debugging
                            Console.WriteLine("Executing Query: " + query);
                            foreach (SqlParameter param in command.Parameters)
                            {
                                Console.WriteLine($"{param.ParameterName}: {param.Value}");
                            }

                            // Execute the query and check for rows affected
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected <= 0)
                            {
                                throw new Exception("Failed to insert the claim.");
                            }
                        }
                    }

                    return true;  // Return true if all claims are successfully saved
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("SQL error occurred while saving claims: " + sqlEx.Message);
                Console.WriteLine("SQL Error: " + sqlEx.Message);  // Add console log for debugging
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving claims: " + ex.Message);
                Console.WriteLine("General Error: " + ex.Message);  // Add console log for debugging
                return false;
            }
        }
    }
}