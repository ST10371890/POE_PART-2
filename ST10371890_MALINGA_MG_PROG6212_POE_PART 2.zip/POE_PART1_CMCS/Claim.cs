﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PART1_CMCS
{
    // Class to represent the Claim object
    public class Claim
    {
        public string LecturerName { get; set; }
        public string LecturerSurname { get; set; }
        public string EmployeeNumber { get; set; }
        public string ContactNumber { get; set; }
        public string ModuleName { get; set; }
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public int ClaimID { get; set; }
        public int TotalHours { get; set; }
        public string Status { get; set; }
        public string claimId { get; set; }
        

        // Total claim calculation
        public decimal TotalClaim
        {
            get { return HoursWorked * HourlyRate; }
        }

        public object LecturerId { get; internal set; }
        public object LecturerID { get; internal set; }
        public object Module { get; internal set; }
        public object DocumentPath { get; internal set; }
      
    }
}