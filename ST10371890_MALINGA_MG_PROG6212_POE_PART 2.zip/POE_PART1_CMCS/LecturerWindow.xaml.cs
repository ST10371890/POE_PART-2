﻿using Microsoft.Win32;
using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Claims;

namespace POE_PART1_CMCS
{
    /// <summary>
    /// Interaction logic for LecturerWindow.xaml
    /// </summary>
    public partial class LecturerWindow : Window
    {
        public LecturerWindow()
        {
            InitializeComponent();
        }

        // Handler for submitting a claim
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Retrieve input from text fields
            string lecturerName = LecturerNameTextBox.Text;
            string lecturerSurname = LecturerSurnameTextBox.Text;
            string employeeNumber = EmployeeNumberTextBox.Text;
            string contactNumber = ContactNumberTextBox.Text;
            string moduleName = ModuleNameTextBox.Text;
            string hoursWorked = HoursWorkedTextBox.Text;
            string hourlyRate = HourlyRateTextBox.Text;

            // Validate inputs (you can add further validation as needed)
            if (string.IsNullOrEmpty(lecturerName) || string.IsNullOrEmpty(lecturerSurname) ||
                string.IsNullOrEmpty(employeeNumber) || string.IsNullOrEmpty(contactNumber) ||
                string.IsNullOrEmpty(moduleName) || string.IsNullOrEmpty(hoursWorked) || string.IsNullOrEmpty(hourlyRate))
            {
                MessageBox.Show("Please fill in all fields before submitting.");
                return;
            }

            // Proceed to save the claim (you can replace this with actual database logic)
            MessageBox.Show("Claim submitted successfully!");

            // Optionally, reset fields after submission
            LecturerNameTextBox.Clear();
            LecturerSurnameTextBox.Clear();
            EmployeeNumberTextBox.Clear();
            ContactNumberTextBox.Clear();
            ModuleNameTextBox.Clear();
            HoursWorkedTextBox.Clear();
            HourlyRateTextBox.Clear();
        }

        // Handler for uploading supporting document
        private void UploadDocument_Click(object sender, RoutedEventArgs e)
        {
            // Open a file dialog for selecting a document
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                // Display the file path in the TextBlock
                DocumentPathTextBlock.Text = $"Document: {openFileDialog.FileName}";
            }
        }

        // Handler for adding a module (optional based on requirements)
        private void AddModule_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Module added!");
        }
    }
}