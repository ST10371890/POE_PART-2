﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_PART1_CMCS
{
    /// <summary>
    /// Interaction logic for CoordinatorWindow.xaml
    /// </summary>
    public partial class CoordinatorWindow : Window
    {
       // List to hold claims
        private List<Claim> claims;

        public CoordinatorWindow()
        {
            InitializeComponent();
            LoadPendingClaims(); // Load pending claims when window opens
        }

        // Load all pending claims from the database
        private void LoadPendingClaims()
        {
            claims = new List<Claim>();

            string query = "SELECT ClaimID, LecturerID, ModuleName, HoursWorked, Status FROM Claims WHERE Status = 'Pending'";
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True"))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            claims.Add(new Claim
                            {
                                claimId = reader.GetString(0),
                                LecturerName = GetLecturerName(reader.GetInt32(1)), // Get lecturer's name using LecturerID
                                ModuleName = reader.GetString(2),
                                HoursWorked = reader.GetDecimal(3),
                                Status = reader.GetString(4)
                            });
                        }
                    }
                }

                dgPendingClaims.ItemsSource = claims; // Bind claims to DataGrid
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading claims: " + ex.Message);
            }
        }

        // Get Lecturer's full name using LecturerID
        private string GetLecturerName(int lecturerID)
        {
            string lecturerName = string.Empty;
            string query = "SELECT LecturerName, LecturerSurname FROM Lecturers WHERE LecturerID = @LecturerID";
            using (SqlConnection connection = new SqlConnection("Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True"))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LecturerID", lecturerID);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        lecturerName = reader.GetString(0) + " " + reader.GetString(1);
                    }
                }
            }
            return lecturerName;
        }

        // Approve claim
        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            var selectedClaim = (Claim)dgPendingClaims.SelectedItem;
            if (selectedClaim != null)
            {
                UpdateClaimStatus(selectedClaim.claimId, "Approved");
                LoadPendingClaims(); // Refresh the list after approval
            }
            else
            {
                MessageBox.Show("Please select a claim to approve.");
            }
        }

        // Reject claim
        private void RejectClaim_Click(object sender, RoutedEventArgs e)
        {
            var selectedClaim = (Claim)dgPendingClaims.SelectedItem;
            if (selectedClaim != null)
            {
                UpdateClaimStatus(selectedClaim.claimId, "Rejected");
                LoadPendingClaims(); // Refresh the list after rejection
            }
            else
            {
                MessageBox.Show("Please select a claim to reject.");
            }
        }

        // Update claim status in the database
        private void UpdateClaimStatus(string claimID, string newStatus)
        {
            string query = "UPDATE Claims SET Status = @Status WHERE ClaimID = @ClaimID";
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=MALINGA\\SQLEXPRESS;Initial Catalog=PART2_DB;Integrated Security=True"))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Status", newStatus);
                        command.Parameters.AddWithValue("@ClaimID", claimID);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show($"Claim {claimID} has been {newStatus.ToLower()}.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating claim status: " + ex.Message);
            }
        }

        // Handle DataGrid selection change event to update UI
        private void dgPendingClaims_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedClaim = (Claim)dgPendingClaims.SelectedItem;
            if (selectedClaim != null)
            {
                txtSelectedClaimID.Text = selectedClaim.claimId;
                txtSelectedStatus.Text = selectedClaim.Status;
            }
        }
    }
}